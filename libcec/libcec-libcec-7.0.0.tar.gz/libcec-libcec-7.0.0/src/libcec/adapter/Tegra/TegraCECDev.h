#define TEGRA_CEC_DEV_PATH "/dev/tegra_cec"
#define TEGRA_CEC_FRAME_MAX_LENGTH  16
#define TEGRA_ADDR_PATH "/sys/devices/platform/tegra_cec/cec_logical_addr_config"
